package com.panda.web.controller.system;

import com.panda.common.constant.MovieRankingList;
import com.panda.common.response.ResponseResult;
import com.panda.system.domin.Review;
import com.panda.system.domin.ReviewRequest;
import com.panda.system.domin.SysMovie;
import com.panda.system.domin.vo.MovieBoxOfficeVO;
import com.panda.system.domin.vo.SysMovieVo;
import com.panda.system.service.impl.SysMovieServiceImpl;
import com.panda.web.controller.BaseController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

@Slf4j
@RestController
public class SysMovieController extends BaseController {

    @Autowired
    private SysMovieServiceImpl sysMovieService;

    @GetMapping("/newReleases")
    public ResponseEntity<List<SysMovie>> getNewReleases() {
        List<SysMovie> newReleases = sysMovieService.getNewReleases();
        return new ResponseEntity<>(newReleases, HttpStatus.OK);
    }


    /**
     * 获取推荐电影列表（按评分从高到低排序）
     * @return 推荐的电影列表
     */
    @GetMapping("/topRatedList")
    public ResponseEntity<List<SysMovie>> getTopRatedMovies() {
        List<SysMovie> movies = sysMovieService.getTopRatedMovies();  // 调用服务层获取电影列表
        if (movies == null || movies.isEmpty()) {
            // 如果没有数据，打印日志确保后端正常工作
            log.warn("未找到推荐电影。");
            return ResponseEntity.noContent().build();  // 返回204状态码，无内容
        }
        return ResponseEntity.ok(movies);  // 返回200状态码和推荐电影列表
    }


    @GetMapping("/sysMovie/{movieId}/reviews")
    public ResponseResult getReviewsByMovieId(
            @PathVariable Long movieId,
            @RequestParam(value = "sortType", defaultValue = "latest") String sortType) {
        List<Review> reviews = sysMovieService.getReviewsByMovieId(movieId, sortType);
        return getResult(reviews);
    }

    @GetMapping("/sysMovie/{movieId}/rating")
    public ResponseResult getMovieRating(@PathVariable Long movieId) {
        Double avgRating = sysMovieService.calculateAverageRating(movieId);
        return ResponseResult.success(avgRating != null ? avgRating : 0.0);
    }

    // 提交评论和评分
    @PostMapping("/sysMovie/{movieId}/reviews")
    public ResponseResult submitReview(@PathVariable Long movieId, @RequestBody ReviewRequest reviewRequest) {
        sysMovieService.submitReview(movieId, reviewRequest.getUserId(), reviewRequest.getRating(), reviewRequest.getComment());
        return ResponseResult.success("Review submitted successfully");
    }
    @GetMapping("/sysMovie/find")
    public ResponseResult findAllMovies(SysMovieVo sysMovieVo) {
        startPage();
        List<SysMovie> data = sysMovieService.findAllMovies(sysMovieVo);
        return getResult(data);
    }

    @GetMapping("/sysMovie/find/{id}")
    public ResponseResult findMovieById(@PathVariable Long id) {
        return getResult(sysMovieService.findMovieById(id));
    }

    @PostMapping("/sysMovie")
    public ResponseResult addMovie(@Validated @RequestBody SysMovie sysMovie) {
        return getResult(sysMovieService.addMovie(sysMovie));
    }

    @PutMapping("/sysMovie")
    public ResponseResult updateMovie(@Validated @RequestBody SysMovie sysMovie) {
        return getResult(sysMovieService.updateMovie(sysMovie));
    }

    @DeleteMapping("/sysMovie/{ids}")
    public ResponseResult deleteMovie(@PathVariable Long[] ids) {
        return getResult(sysMovieService.deleteMovie(ids));
    }

    @GetMapping("/sysMovie/find/rankingList/{listId}")
    public ResponseResult findRankingList(@PathVariable Integer listId) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        if (listId <= 0 || listId > 4) {
            //暂时只支持4种榜单
            return ResponseResult.error("抱歉，暂时只支持3种榜单，id为[1,3]");
        }
        Method getList = sysMovieService.getClass().getMethod(MovieRankingList.listNames[listId - 1]);
        startPage();
        List<SysMovie> data = (List<SysMovie>) getList.invoke(sysMovieService);
        return getResult(data);
    }
    /**
     * 获取票房统计数据
     */
    @GetMapping("/sysMovie/boxOffice")
    public ResponseResult getBoxOfficeStatistics() {  // 改用统一返回格式
        List<MovieBoxOfficeVO> statistics = sysMovieService.getBoxOfficeStatistics();
        return getResult(statistics);  // 使用统一的返回方法
    }

}
