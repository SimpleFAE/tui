package com.panda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PandaAdminApplication {

    public static void main(String[] args) {
        SpringApplication.run(PandaAdminApplication.class, args);
    }

}
