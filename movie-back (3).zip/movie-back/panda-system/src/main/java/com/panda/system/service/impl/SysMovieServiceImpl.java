package com.panda.system.service.impl;

import com.panda.system.domin.Review;
import com.panda.system.domin.SysMovie;
import com.panda.system.domin.vo.MovieBoxOfficeVO;
import com.panda.system.domin.vo.SysMovieVo;
import com.panda.system.mapper.SysMovieMapper;
import com.panda.system.service.SysMovieService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SysMovieServiceImpl implements SysMovieService {

    @Autowired
    private SysMovieMapper sysMovieMapper;

    /**
     * 获取新电影列表
     * @return 的电影列表
     */


    @Override
    public List<SysMovie> getNewReleases() {
        return sysMovieMapper.findNewReleases();
    }

    /**
     * 获取按评分从高到低的推荐电影列表
     * @return 推荐的电影列表
     */
    @Override
    public List<SysMovie> getTopRatedMovies() {
        return sysMovieMapper.getTopRatedMovies();  // 调用Mapper层获取数据
    }

    @Override
    public Double calculateAverageRating(Long movieId) {
        return sysMovieMapper.calculateAverageRating(movieId);
    }


    @Override
    public List<Review> getReviewsByMovieId(Long movieId, String sortType) {
        switch (sortType) {
            case "latest":
                return sysMovieMapper.getReviewsByDateDesc(movieId);
            case "highest":
                return sysMovieMapper.getReviewsByRatingDesc(movieId);
            case "lowest":
                return sysMovieMapper.getReviewsByRatingAsc(movieId);
            default:
                throw new IllegalArgumentException("Invalid sort type: " + sortType);
        }
    }


    // 获取电影的评论
    @Override
    public List<Review> getReviewsByMovieId(Long movieId) {
        return sysMovieMapper.getReviewsByMovieId(movieId);
    }




    // 提交评论并更新评分
    @Override
    public void submitReview(Long movieId, Long userId, Integer rating, String comment) {
        // 插入评论到数据库
        sysMovieMapper.insertReview(movieId, userId, rating, comment);
        log.info("Successfully submitted review for movieId: {}", movieId);  // 打印日志

        // 更新电影评分
        updateMovieRating(movieId);
    }

    private void updateMovieRating(Long movieId) {
        // 计算电影的新评分
        Double avgRating = sysMovieMapper.calculateAverageRating(movieId);
        if (avgRating == null) {
            avgRating = 0.0; // 如果没有评分，设置为 0
        }
        sysMovieMapper.updateMovieRating(movieId, avgRating);
        log.info("Updated movie rating for movieId: {} to {}", movieId, avgRating);
    }


    @Override
    public List<SysMovie> findAllMovies(SysMovieVo sysMovieVo) {
        return sysMovieMapper.findAllMovies(sysMovieVo);
    }

    @Override
    public SysMovie findMovieById(Long id) {
        return sysMovieMapper.findMovieById(id);
    }

    @Override
    public SysMovie findOneMovie(Long id) {
        return sysMovieMapper.findOneMovie(id);
    }

    @Override
    public int addMovie(SysMovie sysMovie) {
        return sysMovieMapper.addMovie(sysMovie);
    }

    @Override
    public int updateMovie(SysMovie sysMovie) {
        return sysMovieMapper.updateMovie(sysMovie);
    }

    @Override
    public int deleteMovie(Long[] ids) {
        int rows = 0;
        for (Long id : ids) {
            rows += sysMovieMapper.deleteMovie(id);
        }
        return rows;
    }

//    @Override
//    public List<SysMovie> findByCinemaId(Long id) {
//        return sysMovieMapper.findByCinemaId(id);
//    }

    /**
     * 总票房榜
     *
     * @return
     */
    @Override
    public List<SysMovie> totalBoxOfficeList() {
        return sysMovieMapper.totalBoxOfficeList();
    }

    /**
     * 国内票房榜 已上映的国内电影里，按票房取前10 国内电影 movieArea in (港台+大陆)
     *
     * @return
     */
    @Override
    public List<SysMovie> domesticBoxOfficeList() {
        return sysMovieMapper.domesticBoxOfficeList();
    }

    /**
     * 国外票房榜 已上映的国外电影里，按票房取前10 国外电影 movieArea not in (港台+大陆)
     *
     * @return
     */
    @Override
    public List<SysMovie> foreignBoxOfficeList() {
        return sysMovieMapper.foreignBoxOfficeList();
    }

    @Override
    public List<MovieBoxOfficeVO> getBoxOfficeStatistics() {
        log.info("开始获取票房统计数据");
        try {
            List<MovieBoxOfficeVO> result = sysMovieMapper.selectBoxOfficeStatistics();
            log.info("获取到票房数据: {}", result);
            return result;
        } catch (Exception e) {
            log.error("获取票房统计数据失败", e);
            throw e;
        }
    }


}
