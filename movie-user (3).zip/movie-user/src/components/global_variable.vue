
<script>
const base = 'http://127.0.0.1:8181/'

export default {
  base
}

</script>
